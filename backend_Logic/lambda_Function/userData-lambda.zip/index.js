const { DynamoDB } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocument } = require('@aws-sdk/lib-dynamodb');

// Initialize DynamoDB client
const dynamoDbClient = new DynamoDB({});
const dynamoDbDocClient = DynamoDBDocument.from(dynamoDbClient);

// Function to fetch data from DynamoDB
const fetchDataFromDynamoDB = async () => {
  const params = {
    TableName: 'login-database',  // Replace with your DynamoDB table name
  };

  try {
    console.log("Fetching data from DynamoDB with params:", params);
    const data = await dynamoDbDocClient.scan(params);
    console.log("Data fetched from DynamoDB:", data);
    return data.Items;
  } catch (error) {
    console.error('Error fetching data from DynamoDB:', error);
    throw new Error('Could not fetch data');
  }
};

let usercount = [];
// Helper function to process data (extract specific fields)
const processUserData = (data) => {
  const users = data.map(user => {
    return `Username: ${user.username || 'Unknown'}, Nationality: ${user.nationality || 'Unknown'}, Last Login: ${user.lastlogin || 'No login timestamp'}`;
  });
  
  // if (user in users) {
      
  //   }

  return users.join('\\n');
};

// Lambda handler
module.exports.handler = async (event) => {
  try {
    console.log("Received event:", JSON.stringify(event));

    // Fetch data from DynamoDB
    const data = await fetchDataFromDynamoDB();
    if (!data) {
      throw new Error("No data found in DynamoDB");
    }
    const processedData = processUserData(data);

    // Return the result as a JSON response
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: processedData,
    };
  } catch (error) {
    console.error('Error processing request:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to process request', details: error.message }),
    };
  }
};
