import nodemailer from "nodemailer";

// create reusable transporter object using the default SMTP transport
const transporter = nodemailer.createTransport({
    service: "gmail",
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
        user: "koomsonjude76@gmail.com",
        pass: "tune nyok ssdc gwnl"
    },
});

// /** create reusable sendmail function 
// @params {object} options - mail options (to, subject, text, html)
// @params {function} callback - callback function to handle response
// */
const SENDMAIL = async (mailDetails, callback) => {
    try {
        const info = await transporter.sendMail(mailDetails);
        callback(info);
    } catch (error) {
        console.log(error);
    }
};

export default SENDMAIL;