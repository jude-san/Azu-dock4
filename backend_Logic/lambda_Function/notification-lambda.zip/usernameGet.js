export const extractEmail = async (event) => {
    
    // const email = [];
    
    for (const record of event.Records) {
        if (record.eventName === 'INSERT') {
            const newItem = record.dynamodb.NewImage;

            // Extract the email from the new item
            const userEmail = newItem.email.S;
            
            console.log('Extracted Email:', userEmail);

            return userEmail;
        }
    }
    return null;
};
