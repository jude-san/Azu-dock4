const builder = require("../utils/builder");
const bcrypt = require("bcryptjs");
const auth = require("../utils/auth");
const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient({
region: 'eu-west-2', 
apiVersion: '2012-08-10',
});  //Here is the region your database is located.


const SALT_ROUND = 8;

async function login(username, password){
if(!username || !password){
return builder.buildResponse(400, {message: "Missing required fields"});
}

// console.log("Username input:", getUser(username));
const foundUser = await getUser(username);
if(!foundUser || !foundUser.username){ // user doesn’t exist in database
return builder.buildResponse(400, {message: "User doesn\'t exist", foundUser});
}
if(!bcrypt.compareSync(password, foundUser.password)){ // password doesn’t match with the existing password
return builder.buildResponse(403, {message: "Wrong Password"});
}


const token = auth.generateToken(foundUser.username); // generate token encapsulating username
const tokenArray = foundUser.tokens || [];
const timestamp = new Date().toISOString();
tokenArray.push(token); // store the generated token in the database
const params = {
Key: {
username: username
},
UpdateExpression: `set tokens = :value, lastlogin = :timestamp`,
ExpressionAttributeValues: {
":value": tokenArray,
":timestamp": timestamp
},
TableName: "login-database",
ReturnValues: "UPDATED_NEW"
};

const response = {
name: foundUser.name,
username: foundUser.username,
password: foundUser.password,
email: foundUser.email,
age: foundUser.age,
maritalstatus: foundUser.maritalstatus,
occupation: foundUser.occupation,
nationality: foundUser.nationality,
token: token
};


return await dynamoDB.update(params).promise().then(()=>{
return builder.buildResponse(200, {message:"User logged in successfully", response});
}).catch((err)=>{
return builder.buildResponse(400, {message: err});
})
}


// retrieve user data via username from DynamoDB
const getUser = async (username)=>{
const params = {
Key: {
    username: username
},
TableName: "login-database"   //change databaes name to respective database created.
}

return await dynamoDB.get(params).promise().then((response)=>{
return response.Item;
}).catch((err)=>{
return err;
})


}

module.exports.login = login;