const builder = require("../utils/builder");
const bcrypt = require("bcryptjs");
const auth = require("../utils/auth");
const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient({
region: 'eu-west-2',
apiVersion: '2012-08-10',
}); //Here is the region your database is located.

async function logout(username, token){
if(!username || !token){
return builder.buildResponse(400, {message: "Missing required fields"});
}

const foundUser = await getUser(username);
if(!foundUser || !foundUser.username){ // user doesn’t exist in database
return builder.buildResponse(400, {message: "User doesn\'t exist"});
}

// user is already logged out
if(!foundUser.tokens || !foundUser.tokens.includes(token)){
return builder.buildResponse(400, {message: "User is not authenticated"});
}
// remove the current token from the database
const tokenArray = foundUser.tokens.filter(currToken => currToken !== token);

const params = {
Key: {
username: username
},
UpdateExpression: `set tokens = :value`,
ExpressionAttributeValues: {
":value": tokenArray
},
TableName: "login-database",
ReturnValues: "UPDATED_NEW"
};

return await dynamoDB.update(params).promise().then(()=>{
return builder.buildResponse(200, {message: "Logged out successfully"});
}).catch((err)=>{
return builder.buildResponse(400, {message: err});
})
}

// retrieve user data via username from DynamoDB
const getUser = async (username)=>{
const params = {
Key: {
username: username
},
TableName: "login-database"  //change databaes name to respective database created.
}

return await dynamoDB.get(params).promise().then((response)=>{
return response.Item;
}).catch((err)=>{
return err;
})
}

module.exports.logout = logout;