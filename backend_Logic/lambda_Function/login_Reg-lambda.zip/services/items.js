// here where dat would be outputted:
// users logged onto the app
// Number of users
// Timestamp of logging onto  the app
// Nationality counts

const builder = require("../utils/builder");
const AWS = require("aws-sdk");
const dynamoDb = new AWS.DynamoDB.DocumentClient({
region: 'eu-west-2', 
apiVersion: '2012-08-10',
}); //Here is the region your database is located.

// Initialize DynamoDB client

// Function to fetch data from DynamoDB
const fetchDataFromDynamoDB = async () => {
  const params = {
    TableName: 'login-database', // Replace with your DynamoDB table name
  };

  try {
    const data = await dynamoDb.scan(params).promise();
    return data.Items;
  } catch (error) {
    console.error('Error fetching data from DynamoDB:', error);
    throw new Error('Could not fetch data');
  }
};

// Helper function to process data
const processUserData = (data) => {
  let numberOfUsers = 0;
  let nationalityCounts = {};
  let loginTimestamps = [];

  data.forEach((user) => {
    numberOfUsers += 1;
    loginTimestamps.push(user.loginTimestamp);

    const nationality = user.nationality || 'Unknown';
    if (nationalityCounts[nationality]) {
      nationalityCounts[nationality]++;
    } else {
      nationalityCounts[nationality] = 1;
    }
  });

  return {
    numberOfUsers,
    loginTimestamps,
    nationalityCounts,
  };
};

// Lambda handler
export const handler = async (event) => {
  try {
    // Fetch data from DynamoDB
    const data = await fetchDataFromDynamoDB();
    const processedData = processUserData(data);

    // Return the result as a JSON response
    return {
      statusCode: 200,
      body: JSON.stringify({
        numberOfUsers: processedData.numberOfUsers,
        loginTimestamps: processedData.loginTimestamps,
        nationalityCounts: processedData.nationalityCounts,
      }),
    };
  } catch (error) {
    console.error('Error processing request:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to process request' }),
    };
  }
};



module.exports.items = items;