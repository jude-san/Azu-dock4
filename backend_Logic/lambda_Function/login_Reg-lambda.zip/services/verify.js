const auth = require("../utils/auth");
const builder = require("../utils/builder");
const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient({
region: 'eu-west-2',
apiVersion: '2012-08-10',
});

async function verify(username, token){
if(!username || !token) return builder.buildResponse(400, {
verified: false,
message: "Missing required fields"
});

// verify the validation of the current token
const verificationResponse = auth.verifyToken(username, token);
if(!verificationResponse.verified) return builder.buildResponse(400, verificationResponse);

const foundUser = await getUser(username);
if(!foundUser || !foundUser.username || !foundUser.tokens) return builder.buildResponse(400, {verified: false, message: "Missing Fields detected"});
if(!foundUser.tokens.includes(token)) return builder.buildResponse(400, {verified: false, message: "User is not authenticated"});

return builder.buildResponse(200, {
verified: true,
message: "success",
username,
token
});
}

// retrieve user data via username from DynamoDB
const getUser = async (username)=>{
const params = {
Key: {
username: username
},
TableName: "login-database"
}

return await dynamoDB.get(params).promise().then((response)=>{
return response.Item;
}).catch((err)=>{
return err;
})
}

module.exports.verify = verify;