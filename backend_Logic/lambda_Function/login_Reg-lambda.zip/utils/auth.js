const jwt = require("jsonwebtoken");

// generate a token encapsulating the username (expires after 1 hour)
const generateToken = (username)=>{
if(!username) return null;

return jwt.sign({username}, process.env.JWT_SECRET, {
expiresIn: '1h'
})
}

// verify the validation of the current token
const verifyToken = (username, token)=>{
return jwt.verify(token, process.env.JWT_SECRET, (error, response)=>{
if(error) return {verified: false, message: "Invalid Token"};
if(response.username !== username) return {verified: false, message: "Invalid User"};
return {verified: true, message: "User is verified"};
})
}

module.exports.generateToken = generateToken;
module.exports.verifyToken = verifyToken;