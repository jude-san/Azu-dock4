const buildResponse = (statusCode, data)=>{
return {
statusCode: statusCode,
headers: { "Content-Type": "application/json" },
body: data,
};
}

module.exports.buildResponse = buildResponse;