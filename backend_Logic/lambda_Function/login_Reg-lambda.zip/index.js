const registerService = require("./services/register");
const loginService = require("./services/login");
const verifyService = require("./services/verify");
const logoutService = require("./services/logout");
const builder = require("./utils/builder");


// DO NOT CHANGE THE INPUT ARRANGEMENTS!!!!!!!!!
exports.handler = async (event) => {
if (event.path === "/register" && event.httpMethod === "POST") { // handling user’s sign up process
const response = await registerService.register(
event.name, // NEVER CHANGE IT PLS
event.username,
event.password, // UNLESS YOU WANT ERRORS!!
event.email,
event.age, 
event.nationality,
event.maritalstatus,
event.occupation,
);
return builder.buildResponse(200, response);
} else if (event.path === "/login" && event.httpMethod === "POST") { // handling user’s sign in process
const response = await loginService.login(event.username, event.password);
return builder.buildResponse(200, response);
} else if (event.path === "/verify" && event.httpMethod === "POST") { // handling user’s auth-verification process
const response = await verifyService.verify(event.username, event.token);
return builder.buildResponse(200, response);
} else if (event.path === "/logout" && event.httpMethod === "POST") { // handling user’s signout process
const response = await logoutService.logout(event.username, event.token);
return builder.buildResponse(200, response);

} else {
return builder.buildResponse(400, {
message: `${event.httpMethod} is not allowed in ${event.path} route`,
});
}
};