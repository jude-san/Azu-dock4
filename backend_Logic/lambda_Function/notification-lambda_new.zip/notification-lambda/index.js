import HTML_TEMPLATE from "./mail-template.js";
import { extractEmail } from './usernameGet.js';
import SENDMAIL from "./mailer.js";

export const handler = async (event) => {
const email = await extractEmail(event);

console.log('Exported Email:', email); 
const message = "Thank you for filling out the form. Welcome to the Gold Grid family.";

const options = {
    from: "AI Mavericks <koomsonjude76@gmail.com>", // sender address
    to: email, // receiver email
    subject: "Welcome to the family!!!", // Subject line
    text: message,
    html: HTML_TEMPLATE(message),
};


// send mail with defined transport object and mail options
// SENDMAIL(options, (info) => {
//     console.log("Email sent successfully");
//     console.log("MESSAGE ID: ", info.messageId);
// });

return new Promise((resolve, reject) => {
    SENDMAIL(options, (err, info) => {
        if (true) {
             // currently outputs errors statements intead of success message but it works tho ;) 
            console.log("Email sent successfully");
            console.log("Message ID:", info.messageId);
            resolve(info); // Resolve the promise with success info
            reject(err);
        } else {
           // very confusing, this output success logs as errors
            console.error("SENDMAIL Error:", JSON.stringify(err, null, 2));
        }
    });
});
    
    
    
    
};